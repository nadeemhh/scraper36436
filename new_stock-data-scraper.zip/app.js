const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const app = express();
app.use(express.json());
app.use(bodyParser.json());
let cors = require("cors");
app.use(cors());
const mongoose = require("mongoose");
const validator = require("validator");
const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const axios = require("axios");
const { json } = require("express/lib/response");
const { Console } = require("console");
const publicDirectoryPath = path.join(__dirname, "./client");
app.use(express.static(publicDirectoryPath));

const port = process.env.PORT || 3400;


mongoose.connect('mongodb+srv://pivotpoint:767967574@cluster0.fw3uvzc.mongodb.net/?retryWrites=true&w=majority')

const Stockcheck = mongoose.model('Stockcheck', {
  scriptName : {
    type: String
       
    },
   
})

const SPY = mongoose.model('spy', {
  scriptName : {
    type: String
       
    },
   
})

const Alerts = mongoose.model('Alerts', {
  Alert : {
    type: String
       
    },
   
})

const Alertsforcrypto = mongoose.model('Alertsforcrypto', {
  Alert : {
    type: String
       
    },

    date : {
      type: String
         
      },
   
})


let globalDom=undefined;

app.post('/addstock', async (req, res) => {
  console.log('req.query',req.body)

  const Stockchecks = new Stockcheck({
      scriptName:req.body.scriptname,
   
   })
   Stockchecks.save()
  res.send({'done':'done'})
      })


      app.post('/removestock', async (req, res) => {
          console.log('req.query',req.body)
      let del=await Stockcheck.deleteMany({scriptName:req.body.scriptname});
          
          res.send({'done':'done'})
              })

              app.get('/countnum', async (req, res) => {
                let dayname = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
                const d = new Date();
                let day = d.getDay()
                console.log(day,dayname[day],d.toLocaleString())

                   let date=new Date();

                   let cryptoalerts = await Alertsforcrypto.find({}).exec();
                  
                   let checkalerts = await Alerts.find({}).exec();

                res.send({'alerts':`${checkalerts.length}`,'nytimaanddate':`${date.toLocaleString('en-US', {
                  timeZone: 'America/New_York',
                }).split(',')[1].replace(' ','').replace(' ','')}`,'weekname':`${dayname[day]}`,'cryptoalerts':`${cryptoalerts.length}`,'currenttime':`${d.toLocaleString()}`})
                    })
                   
                    

                    app.get('/allstocklist', async (req, res) => {
                      let stock = await Stockcheck.find({}).exec();
                      //console.log(stock)
                      let stocklist=[];

                   for(let i =0; i<stock.length; i++){

                    stocklist.push(stock[i].scriptName)

                   }
                  
                   res.send(JSON.stringify(stocklist))
                       })



app.post("/fetchdata", async (req, res) => {
  console.log("req.body", req.body);

  let income_range = [];
  let insertd_data = [];

  async function srlevels() {
    const response = await axios.get(
      req.body.symboltype == "crypto"
        ? `https://www.barchart.com/crypto/quotes/%5E${req.body.scriptname.replace(
            "-",
            ""
          )}`
        : `https://www.barchart.com/stocks/quotes/${req.body.scriptname}/overview`,
      {
        headers: {
          accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
          "accept-language": "en-US,en;q=0.9",
          "sec-ch-ua":
            '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "none",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
          cookie:
            "_gcl_au=1.1.938838118.1662273627; _ga=GA1.2.597722947.1662273638; _fbp=fb.1.1662273648937.747945183; _admrla=2.2-1d31543b0f239ce5-a2b7e234-2c1c-11ed-8454-9a525b0fb3fd; __qca=P0-509516544-1662273765997; _pbjs_userid_consent_data=3524755945110770; _pubcid=218e8df8-8f1d-404f-8613-a7f374a5d1e1; _lr_env_src_ats=false; _cc_id=6b7f7be91435042cd8725f816d970566; cnx_userId=7a11b5bede684057bb69a1a5e0e486c8; pbjs-unifiedid=%7B%22TDID%22%3A%22c00706a2-fb07-4cf3-bb42-e617d73f70d3%22%2C%22TDID_LOOKUP%22%3A%22TRUE%22%2C%22TDID_CREATED_AT%22%3A%222022-10-08T06%3A43%3A43%22%7D; __browsiUID=7b8112c8-c482-4d6e-aed9-7c92f29a3dee; __gads=ID=210762910cd1465e-22f44a6d65d8003d:T=1662273666:S=ALNI_MbEUTAfxPTsPqkrpL_NV8idvZUpNA; cto_bundle=1GLOpV90b0Y1MVdTb09PYUtiOHFJZSUyQm9ZbGt4dlRHZ2UwSnczZTklMkJuZHM3OHdHbXo2aGhBUCUyRjdjWURBaUlneHRmQjZleEJvT1d5dzgyaW8lMkZWRTF2cDhFeCUyQlQ4TnU1Qk92U1BaYmo2YWZTMTRGRjdONEdXN2w4Z2d1MFJ3RVhlMnY4OHFrb3YzeUx6WmFkNjN5VlpVYkE1bThBJTNEJTNE; __gpi=UID=000009703d106ffc:T=1662273666:RT=1669133528:S=ALNI_MYVJXNT3SwFdR4QCeOSd51VBGXGZA; _awl=2.1669133542.0.5-16f7f4dc8fb9e74d8d88b7350f809572-6763652d617369612d6561737431-0",
        },
        referrerPolicy: "strict-origin-when-cross-origin",
        body: null,
        method: "GET",
      }
    );
    const dom = new JSDOM(response.data);
    console.log("S&R");
    for (let ii = 0; ii < 7; ii++) {
      if (ii != 3) {
        console.log(
          dom.window.document
            .querySelectorAll(".barchart-table")[0]
            .children[0].children[0].children[
              ii
            ].children[0].textContent.replace(",", "")
        );
        console.log(
          "S&R",
          dom.window.document
            .querySelectorAll(".barchart-table")[0]
            .children[0].children[0].children[
              ii
            ].children[1].textContent.replace(",", "")
        );

        insertd_data.push(
          dom.window.document
            .querySelectorAll(".barchart-table")[0]
            .children[0].children[0].children[
              ii
            ].children[1].textContent.replace(",", "")
        );
      }
    }
    console.log("end");
    getp2();
  }

  srlevels();

  async function getp2() {
    req.body.scriptname == "UNI-USD"
      ? (req.body.scriptname = "UNI7083-USD")
      : req.body.scriptname;
    req.body.scriptname == "MATIC-US"
      ? (req.body.scriptname = "MATIC-USD")
      : req.body.scriptname;
    console.log("$$$$$$$$@", req.body);
    const response = await axios.get(
      `https://finance.yahoo.com/quote/${req.body.scriptname}/`,
      {
        headers: {
          accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
          "accept-language": "en-US,en;q=0.9",
          "cache-control": "max-age=0",
          "sec-ch-ua":
            '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "same-origin",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
          cookie:
            "B=3jiu94ph4dccr&b=3&s=n1; maex=%7B%22v2%22%3A%7B%7D%7D; GUC=AQEBCAFjhHNjr0IexwSR&s=AQAAAML0_gFb&g=Y4MrJg; A1=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA; A3=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA; A1S=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA&j=WORLD; cmp=t=1669703979&j=0&u=1---; PRF=t%3DAAP%252BAAPL%252BSTZ%252BCNXC%252BAVGO%252BMOS%252BISIG%252BGPI%252BAPPL%252BAPP%252BETC-USD%252BSPXL%252BLOW%252BGOOG%252BBTC-USD",
        },
        referrerPolicy: "no-referrer-when-downgrade",
        body: null,
        method: "GET",
      }
    );
    const dom = new JSDOM(response.data);

    let currentprice;

    if (req.body.symboltype != "crypto") {
      if (req.body.check_for_afterh_prem == 0) {
        currentprice = dom.window.document
          .querySelectorAll('[data-field="regularMarketPrice"]')[6]
          .textContent.replace(",", "");
      } else {
        try {
          currentprice = dom.window.document
            .querySelector('[data-field="preMarketPrice"]')
            .textContent.replace(",", "");
        } catch (err) {
          console.log("change");
          currentprice = dom.window.document
            .querySelector('[data-field="postMarketPrice"]')
            .textContent.replace(",", "");
        }
      }
    } else {
      currentprice = dom.window.document
        .querySelectorAll('[data-field="regularMarketPrice"]')[6]
        .textContent.replace(",", "");
    }

    insertd_data.push(currentprice);

    if (
      req.body.symboltype != "crypto" &&
      req.body.scriptname != "SPXS" &&
      req.body.scriptname != "FNGD" &&
      req.body.scriptname != "NRGD" &&
      req.body.scriptname != "SOXS" &&
      req.body.scriptname != "SH" &&
      req.body.scriptname != "SDS" &&
      req.body.scriptname != "BERZ" &&
      req.body.scriptname != "PSQ" &&
      req.body.scriptname != "QID" &&
      req.body.scriptname != "SPXL"
    ) {
      //PE Ratio (TTM)

      insertd_data.push(
        dom.window.document.querySelectorAll('[data-test="PE_RATIO-value"]')[0]
          .textContent
      );

      //EPS (TTM)

      insertd_data.push(
        dom.window.document.querySelectorAll('[data-test="EPS_RATIO-value"]')[0]
          .textContent
      );

      income_range.push(
        dom.window.document
          .querySelectorAll('[data-test="DAYS_RANGE-value"]')[0]
          .textContent.replaceAll(" ", "")
          .split("-")[0]
      );
      income_range.push(
        dom.window.document
          .querySelectorAll('[data-test="DAYS_RANGE-value"]')[0]
          .textContent.replaceAll(" ", "")
          .split("-")[1]
      );

      getp();
    } else {
      console.log("$$ crypto $$");
      /////crypto data

      async function crypto() {
        let crypto;
        let cryname = req.body.scriptname;
        switch (cryname) {
          case "ADA-USD":
            crypto = "cardano";
            break;
          case "AVAX-USD":
            crypto = "avalanche";
            break;
          case "BCH-USD":
            crypto = "bitcoin-cash";
            break;
          case "BTC-USD":
            crypto = "bitcoin";
            break;
          case "DOGE-USD":
            crypto = "dogecoin";
            break;
          case "ETC-USD":
            crypto = "ethereum-classic";
            break;
          case "ETH-USD":
            crypto = "ethereum";
            break;
          case "LINK-USD":
            crypto = "chainlink";
            break;
          case "MATIC-USD":
            crypto = "polygon";
            break;
          case "SHIB-USD":
            crypto = "shiba-inu";
            break;
          case "SOL-USD":
            crypto = "solana";
            break;
          case "UNI7083-USD":
            crypto = "uniswap";
            break;
          case "XLM-USD":
            crypto = "stellar";
            break;
          case "AAVE-USD":
            crypto = "aave";
        }
        console.log("crypto --", crypto);
        if (crypto != undefined) {
          const response = await axios.get(
            `https://coinmarketcap.com/currencies/${crypto}/`,
            {
              headers: {
                accept:
                  "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "accept-language": "en-US,en;q=0.9",
                "sec-ch-ua":
                  '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "cross-site",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": "1",
                cookie:
                  "gtm_session_first=%222022-10-07T06%3A03%3A00.069Z%22; _ga=GA1.2.1831258701.1666773613; _fbp=fb.1.1666773631526.616914333; bnc-uuid=8cd64480-c89a-4287-9212-89afc08cc923; se_gd=Q5SCFThoEFOUQIbMbFhMgZZBhUARRBWWlFVRQVkNFdTVADVNXVIT1; se_gsd=fwAlPDtVIi00CQ0mISI3M1Y2WgQUDgUAVVVBVFdaVVdVDVNS1; BNC_FV_KEY_EXPIRE=1666860245984; cmc_gdpr_hide=1; _tt_enable_cookie=1; _ttp=5a7aa59a-71f4-4bee-817a-b4deb67ffe30; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22183b10a32383ef-0c7a46a7938f588-26021c51-1049088-183b10a323a184%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E8%87%AA%E7%84%B6%E6%90%9C%E7%B4%A2%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC%22%2C%22%24latest_referrer%22%3A%22https%3A%2F%2Fwww.google.com%2F%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMTgzYjEwYTMyMzgzZWYtMGM3YTQ2YTc5MzhmNTg4LTI2MDIxYzUxLTEwNDkwODgtMTgzYjEwYTMyM2ExODQifQ%3D%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%22%2C%22value%22%3A%22%22%7D%2C%22%24device_id%22%3A%22183b10a32383ef-0c7a46a7938f588-26021c51-1049088-183b10a323a184%22%7D; gtm_session_last=%222022-11-16T15%3A59%3A42.013Z%22",
                Referer: "https://www.google.com/",
                "Referrer-Policy": "origin",
              },
              body: null,
              method: "GET",
            }
          );

          const dom = new JSDOM(response.data);

          insertd_data.push(
            dom.window.document.querySelectorAll(".namePillPrimary")[0]
              .textContent
          );
          //Rank #1
          for (let i = 0; i < 4; i++) {
            if (crypto == "uniswap") {
              console.log("crypto=='uniswap", crypto == "uniswap");
              for (let i = 0; i < 6; i++) {
                if (i == 1 || i == 3) {
                  continue;
                }
                console.log("crypto=='uniswap", i, i != 1, i != 3);
                insertd_data.push(
                  dom.window.document.querySelectorAll(".statsValue")[i]
                    .textContent
                );
              }

              break;
            } else {
              insertd_data.push(
                dom.window.document.querySelectorAll(".statsValue")[i]
                  .textContent
              );
              //M,F,V,C
            }
          }

          for (let i = 0; i < 2; i++) {
            insertd_data.push(
              dom.window.document.querySelectorAll(".maxSupplyValue")[i]
                .textContent
            );
            //M,T
          }
        }
        console.log("crypto()#");

        console.log(insertd_data);
        res.send(JSON.stringify(insertd_data));
      }

      crypto();
    }
  }

  async function getp() {
    const response = await axios.get(
      `https://finance.yahoo.com/quote/${req.body.scriptname}/key-statistics?p=${req.body.scriptname}`,
      {
        headers: {
          accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
          "accept-language": "en-US,en;q=0.9",
          "cache-control": "max-age=0",
          "sec-ch-ua":
            '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "document",
          "sec-fetch-mode": "navigate",
          "sec-fetch-site": "same-origin",
          "sec-fetch-user": "?1",
          "upgrade-insecure-requests": "1",
          cookie:
            "B=3jiu94ph4dccr&b=3&s=n1; maex=%7B%22v2%22%3A%7B%7D%7D; GUC=AQEBCAFjhHNjr0IexwSR&s=AQAAAML0_gFb&g=Y4MrJg; A1=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA; A3=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA; A1S=d=AQABBJuxRmICEJne7abxJ1xEKWoKsibJyzkFEgEBCAFzhGOvY1lQb2UB_eMBAAcIm7FGYibJyzk&S=AQAAAg0gvuZD3gUlBnvaKMx6BFA&j=WORLD; cmp=t=1669703979&j=0&u=1---; PRF=t%3DAAP%252BBTC-USD%252BAAPL%252BSTZ%252BCNXC%252BAVGO%252BMOS%252BISIG%252BGPI%252BAPPL%252BAPP%252BETC-USD%252BSPXL%252BLOW%252BGOOG",
          Referer: "https://finance.yahoo.com/quote/aap/",
          "Referrer-Policy": "no-referrer-when-downgrade",
        },
        body: null,
        method: "GET",
      }
    );
    const dom = new JSDOM(response.data);

    for (let i = 0; i < 1; i++) {
      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[2].children[1].textContent
      );

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[3].children[1].textContent
      );

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[15].children[1].textContent
      );

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[17].children[1].textContent
      );

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[18].children[1].textContent
      );

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[19].children[1].textContent
      );
      //Total Debt (mrq) 45
      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[45].children[1].textContent
      );
      //total Cash (mrq)

      insertd_data.push(
        dom.window.document.querySelectorAll(".BdY")[8].children[1].textContent
      );
      insertd_data.push(
        dom.window.document.querySelectorAll(".BdB")[41].children[1].textContent
      );

      //low
      insertd_data.push(income_range[0]);
      //high
      insertd_data.push(income_range[1]);
    }

    console.log("insertd_data", insertd_data);
    res.send(JSON.stringify(insertd_data));
    console.log("sents");
  }
});

app.get("/stocksdata", async (req, res) => {

 
  async function re() {
    try {
      console.log(req.query.stockName);
      let otherdata = [];

      let data1 = await axios.get(
        `https://api.nasdaq.com/api/analyst/${req.query.stockName}/peg-ratio`,{
          "headers": {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-US,en;q=0.9",
            "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site"
          },
          "referrer": "https://www.nasdaq.com/",
          "referrerPolicy": "strict-origin-when-cross-origin",
          "body": null,
          "method": "GET",
          "mode": "cors",
          "credentials": "omit"
        });

      let data2 = await axios.get(`https://api.nasdaq.com/api/quote/${req.query.stockName}/summary?assetclass=stocks`, {
        "headers": {
          "accept": "application/json, text/plain, */*",
          "accept-language": "en-US,en;q=0.9",
          "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": "\"Windows\"",
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-site"
        },
        "referrer": "https://www.nasdaq.com/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": null,
        "method": "GET",
        "mode": "cors",
        "credentials": "omit"
      });

      let data3 = await axios.get(
        `https://finance.yahoo.com/quote/${req.query.stockName}/key-statistics?p=${req.query.stockName}`,{
          "headers": {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "en-US,en;q=0.9",
            "cache-control": "max-age=0",
            "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "same-origin",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1"
          },
          "referrerPolicy": "no-referrer-when-downgrade",
          "body": null,
          "method": "GET",
          "mode": "cors",
          "credentials": "include"
        }
      );
   
      const dom = new JSDOM(data3.data);

      let lastPrice = dom.window.document
        .querySelectorAll('[data-field="regularMarketPrice"]')[6]
        .textContent.replace(",", "");

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[17].children[1].textContent
      ); // Float

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[18].children[1].textContent
      ); // Held by Insiders

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[19].children[1].textContent
      ); // Held by Institutions

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[45].children[1].textContent
      ); // Total Debt (mrq)

      otherdata.push(
        dom.window.document.querySelectorAll(".BdY")[8].children[1].textContent
      ); //  Total Cash (mrq)

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[41].children[1].textContent
      ); //Net Income Avi to Common (ttm)

      otherdata.push(
        dom.window.document.querySelectorAll(".BdB")[47].children[1].textContent
      ); // Current Ratio (mrq)

let crosscheckobject={
  pe:{url:`https://finance.yahoo.com/quote/${req.query.stockName}/`,slector:`[data-test="PE_RATIO-value"]`},
  eps:{url:`https://finance.yahoo.com/quote/${req.query.stockName}/`,slector:`[data-test="EPS_RATIO-value"]`},
  exdividend:{url:`https://finance.yahoo.com/quote/${req.query.stockName}/`,slector:`[data-test="EX_DIVIDEND_DATE-value"]`},
  vol:{url:`https://finance.yahoo.com/quote/${req.query.stockName}/`,slector:`[data-field="regularMarketVolume"]`},
  avgvol:{url:`https://finance.yahoo.com/quote/${req.query.stockName}/`,slector:`[data-test="AVERAGE_VOLUME_3MONTH-value"]`},
}

if(data2.data.data.summaryData.PERatio.value=='N/A'){
  console.log('PERatio N/A ')

  data2.data.data.summaryData.PERatio.value=await fetchdataforNA(crosscheckobject.pe.url,crosscheckobject.pe.slector);
}

if(data2.data.data.summaryData.EarningsPerShare.value=='N/A'){
  console.log('EarningsPerShare N/A')
  data2.data.data.summaryData.EarningsPerShare.value=await fetchdataforNA(crosscheckobject.eps.url,crosscheckobject.eps.slector);
}
if(data2.data.data.summaryData.AverageVolume.value=='N/A'){
  console.log('AverageVolume N/A')
  data2.data.data.summaryData.AverageVolume.value=await fetchdataforNA(crosscheckobject.avgvol.url,crosscheckobject.avgvol.slector);
}
if(data2.data.data.summaryData.ShareVolume.value=='N/A'){
  console.log('ShareVolume N/A')
  data2.data.data.summaryData.ShareVolume.value=await fetchdataforNA(crosscheckobject.vol.url,crosscheckobject.vol.slector);
}

if(data2.data.data.summaryData.ExDividendDate.value=='N/A'){
  console.log('ExDividendDate N/A')
  data2.data.data.summaryData.ExDividendDate.value=await fetchdataforNA(crosscheckobject.exdividend.url,crosscheckobject.exdividend.slector);
}

      let objofdata = {
        stockName: req.query.stockName,
        data1: data1.data,
        data2: data2.data,
        lastPrice,
        otherdata,
      };

      //console.log(objofdata);
      res.send(JSON.stringify(objofdata));
      globalDom=undefined;
    } catch (error) {
      console.log(error);
      res.send(
        JSON.stringify({ stockName: req.query.stockName, error: "error" })
      );
    }
  }
  re();
});


app.get("/etfdata", async (req, res) => {
  console.log(req.query.etfName);

  try{

 let data1 = await axios.get(`https://finance.yahoo.com/quote/${req.query.etfName}/`,{
  "headers": {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-US,en;q=0.9",
    "cache-control": "max-age=0",
    "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1"
  },
  "referrerPolicy": "no-referrer-when-downgrade",
  "body": null,
  "method": "GET",
  "mode": "cors",
  "credentials": "include"
});

 const dom = new JSDOM(data1.data);

 let lastPrice = dom.window.document.querySelectorAll('[data-field="regularMarketPrice"]')[6].textContent.replace(",", "");

 let yield = dom.window.document.querySelector('[data-test="TD_YIELD-value"]').textContent;

 let nav = dom.window.document.querySelector('[data-test="NAV-value"]').textContent;

 let vol = dom.window.document.querySelector('[data-field="regularMarketVolume"]').textContent;

 let avgvol = dom.window.document.querySelector('[data-test="AVERAGE_VOLUME_3MONTH-value"]').textContent;

console.log(yield,nav,vol,avgvol)
res.send(JSON.stringify({yield,nav,vol,avgvol,lastPrice,etfName:req.query.etfName}))

  }catch (error) {
  console.log(error);
  res.send(
    JSON.stringify({ etfName: req.query.etfName, error: "error" })
  );
}

})

app.get("/pennystocks", async (req, res) => {
  console.log(req.query.pennyStockName);

  try{
    let otherdata = [];

 let data1 = await axios.get(`https://finance.yahoo.com/quote/${req.query.pennyStockName}/`,{
    "headers": {
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "accept-language": "en-US,en;q=0.9",
      "cache-control": "max-age=0",
      "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": "\"Windows\"",
      "sec-fetch-dest": "document",
      "sec-fetch-mode": "navigate",
      "sec-fetch-site": "same-origin",
      "sec-fetch-user": "?1",
      "upgrade-insecure-requests": "1"
    },
    "referrerPolicy": "no-referrer-when-downgrade",
    "body": null,
    "method": "GET",
    "mode": "cors",
    "credentials": "include"
  });

 const dom = new JSDOM(data1.data);

 let lastPrice = dom.window.document.querySelectorAll('[data-field="regularMarketPrice"]')[6].textContent.replace(",", "");

 let pe=dom.window.document.querySelectorAll('[data-test="PE_RATIO-value"]')[0].textContent;

 let eps=dom.window.document.querySelectorAll('[data-test="EPS_RATIO-value"]')[0].textContent;
 
 let exdividend=dom.window.document.querySelector('[data-test="EX_DIVIDEND_DATE-value"]').textContent;
 
  let vol = dom.window.document.querySelector('[data-field="regularMarketVolume"]').textContent;
 
 let avgvol = dom.window.document.querySelector('[data-test="AVERAGE_VOLUME_3MONTH-value"]').textContent;

 console.log(`https://finance.yahoo.com/quote/${req.query.pennyStockName}/key-statistics?p=${req.query.pennyStockName}`)
 let data3 = await axios.get(
  `https://finance.yahoo.com/quote/${req.query.pennyStockName}/key-statistics?p=${req.query.pennyStockName}`,{
    "headers": {
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "accept-language": "en-US,en;q=0.9",
      "cache-control": "max-age=0",
      "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": "\"Windows\"",
      "sec-fetch-dest": "document",
      "sec-fetch-mode": "navigate",
      "sec-fetch-site": "same-origin",
      "sec-fetch-user": "?1",
      "upgrade-insecure-requests": "1"
    },
    "referrerPolicy": "no-referrer-when-downgrade",
    "body": null,
    "method": "GET",
    "mode": "cors",
    "credentials": "include"
  }
);


let dom2 = new JSDOM(data3.data);

let pegratio= dom2.window.document.querySelectorAll(".BdB")[3].children[1].textContent;

 otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[17].children[1].textContent
); // Float

otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[18].children[1].textContent
); // Held by Insiders

otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[19].children[1].textContent
); // Held by Institutions

otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[45].children[1].textContent
); // Total Debt (mrq)

otherdata.push(
  dom2.window.document.querySelectorAll(".BdY")[8].children[1].textContent
); //  Total Cash (mrq)

otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[41].children[1].textContent
); //Net Income Avi to Common (ttm)

otherdata.push(
  dom2.window.document.querySelectorAll(".BdB")[47].children[1].textContent
); // Current Ratio (mrq)



res.send(JSON.stringify({lastPrice,pe,eps,exdividend,vol,avgvol,pegratio,pennyStockName:req.query.pennyStockName,otherdata,}))

  }catch (error) {
  console.log(error);
  res.send(
    JSON.stringify({ pennyStockName: req.query.pennyStockName, error: "error" })
  );
}

})

async function fetchdataforNA(url,selector) {

  try{

    if(globalDom===undefined){

    let data1 = await axios.get(`${url}`,{
    "headers": {
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "accept-language": "en-US,en;q=0.9",
      "cache-control": "max-age=0",
      "sec-ch-ua": "\"Google Chrome\";v=\"111\", \"Not(A:Brand\";v=\"8\", \"Chromium\";v=\"111\"",
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": "\"Windows\"",
      "sec-fetch-dest": "document",
      "sec-fetch-mode": "navigate",
      "sec-fetch-site": "same-origin",
      "sec-fetch-user": "?1",
      "upgrade-insecure-requests": "1"
    },
    "referrerPolicy": "no-referrer-when-downgrade",
    "body": null,
    "method": "GET",
    "mode": "cors",
    "credentials": "include"
  });

  globalDom = new JSDOM(data1.data);
  }
 return globalDom.window.document.querySelectorAll(selector)[0].textContent;

  }catch(error){console.log(error)}
}

app.listen(port);
